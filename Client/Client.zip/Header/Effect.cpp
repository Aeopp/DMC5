#include "stdafx.h"
#include "Effect.h"


